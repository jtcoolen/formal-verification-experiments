Full version: shor-explainer/main.tex
Two-page prose: shor-prose/main.tex
The one-page synthesis is the opening page of the full project.
Compile each main.tex in its own directory.
